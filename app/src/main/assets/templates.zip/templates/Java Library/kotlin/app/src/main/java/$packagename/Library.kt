package $packagename

public class Library {

}
