package $packagename

import com.badlogic.gdx.ApplicationAdapter
import com.badlogic.gdx.Gdx
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.g2d.SpriteBatch

class GameSuperClass : ApplicationAdapter() {
    private lateinit var spriteBatch: SpriteBatch // Used to draw sprite and textures onto the screen
    private lateinit var texture: Texture // Texture, that will be drawn to a screen

    /* This method is being called when application is created */
    override fun create() {
        spriteBatch = SpriteBatch()
        texture = Texture(Gdx.files.internal("greetings.png"))
    }

    /* This method is being called once every frame */
    override fun render() {
        Gdx.gl.glViewport(0, 0, Gdx.graphics.width, Gdx.graphics.height)
        Gdx.gl.glClearColor(55 / 255f, 55 / 255f, 55 / 255f, 1f)
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT or GL20.GL_DEPTH_BUFFER_BIT)

        spriteBatch.begin()
        spriteBatch.draw(texture, (Gdx.graphics.width - Gdx.graphics.height) / 2f, 0f,
                Gdx.graphics.height.toFloat(), Gdx.graphics.height.toFloat())
        spriteBatch.end()
    }

    /* This method is being called whenever the application is destroyed */
    override fun dispose() {
        spriteBatch.dispose()
        texture.dispose()
    }
}
